export default function NotFound() {
  return (
    <html>
      <body>
        <div>
          <h2>Page Not Found</h2>
          <p>Could not find requested resource</p>
          <div>
            <br />
            <a href="/">
              <b>
                <u>Return Home</u>
              </b>
            </a>
          </div>
        </div>
      </body>
    </html>
  )
}
