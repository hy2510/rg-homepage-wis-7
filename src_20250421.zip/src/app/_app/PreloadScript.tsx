import 'server-only'
import { Swing2AppPreloadScript } from '@/external/swing2app/component/Swing2AppContext'

export default function PreloadScript() {
  return (
    <>
      <Swing2AppPreloadScript />
    </>
  )
}
